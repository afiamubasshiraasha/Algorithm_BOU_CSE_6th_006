package DataStructure;

public class Fibonacci_Loop {

    public static int fib(int x) 
    {
       int n=x;
       int a=0,b=1,c=0;
        if (n == 0)
           return a;
       
        for (int i = 0; i<n; ++i) {
            c=a+b;
          //  System.out.println(""+c);
            a=b;
            b=c;
        }
        return b;
    }
}




