
package DataStructure;

public class Counting_Sort {
      
int getMax(int[] a, int n) 
{  
  int max = a[0];  
  for(int i = 1; i<n; i++) {  
      if(a[i] > max)  
         max = a[i];  
  }  
  return max; //maximum element from the array  
}  
  
void countSort(int[] a, int n) // function to perform counting sort  
{  
   int[] output = new int [n+1];  
   int max = getMax(a, n);  
   //int max = 42;  
   int[] count = new int [max+1]; //create count array with size [max+1]  
  
  for (int i = 0; i <= max; ++i)   
  {  
    count[i] = 0; // Initialize count array with all zeros  
  }  
    
  for (int i = 0; i < n; i++) // Store the count of each element  
  {  
    count[a[i]]++;  
  }  
  
   for(int i = 1; i<=max; i++)   
      count[i] += count[i-1]; //find cumulative frequency  
  
  /* This loop will find the index of each element of the original array in  
 
count array, and 
   place the elements in output array*/  
  for (int i = n - 1; i >= 0; i--) {  
    output[count[a[i]] - 1] = a[i];  
    count[a[i]]--; // decrease count for same numbers  
}  
  
   for(int i = 0; i<n; i++) {  
      a[i] = output[i]; //store the sorted elements into main array  
   }  
}  
  
/* Function to print the array elements */  
void printArray(int a[], int n)  
{  
    int i;  
    for (i = 0; i < n; i++)  
        System.out.print(a[i] + " ");  
}  
  
public static void main(String args[])  
{  
    int a[] = { 11, 30, 24, 7, 31, 16, 39, 41 };  
    int n = a.length;  
    Counting_Sort c1 = new Counting_Sort();  
    System.out.println("\nBefore sorting array elements are - ");  
    c1.printArray(a, n);  
    c1.countSort(a,n);  
    System.out.println("\nAfter sorting array elements are - ");  
    c1.printArray(a, n);  
    System.out.println();  
}  
}  
    


////////////////////////////////////////////////////////////////

// Counting sort in Java programming

//import java.util.Arrays;
//
//class CountingSort {
//  void countSort(int array[], int size) {
//    int[] output = new int[size + 1];
//
//    // Find the largest element of the array
//    int max = array[0];
//    for (int i = 1; i < size; i++) {
//      if (array[i] > max)
//        max = array[i];
//    }
//    int[] count = new int[max + 1];
//
//    // Initialize count array with all zeros.
//    for (int i = 0; i < max; ++i) {
//      count[i] = 0;
//    }
//
//    // Store the count of each element
//    for (int i = 0; i < size; i++) {
//      count[array[i]]++;
//    }
//
//    // Store the cummulative count of each array
//    for (int i = 1; i <= max; i++) {
//      count[i] += count[i - 1];
//    }
//
//    // Find the index of each element of the original array in count array, and
//    // place the elements in output array
//    for (int i = size - 1; i >= 0; i--) {
//      output[count[array[i]] - 1] = array[i];
//      count[array[i]]--;
//    }
//
//    // Copy the sorted elements into original array
//    for (int i = 0; i < size; i++) {
//      array[i] = output[i];
//    }
//  }
//
//  // Driver code
//  public static void main(String args[]) {
//    int[] data = { 4, 2, 2, 8, 3, 3, 1 };
//    int size = data.length;
//    CountingSort cs = new CountingSort();
//    cs.countSort(data, size);
//    System.out.println("Sorted Array in Ascending Order: ");
//    System.out.println(Arrays.toString(data));
//  }
//}