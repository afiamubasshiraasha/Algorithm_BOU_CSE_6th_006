
package DataStructure;
import java.util.Scanner;

/**
 *
 * @author Imran
 */
public class Binary_Search {
  
    
 public static void binarySearch(int arr[], int first, int last, int key){  
   int mid = (first + last)/2;  
   while( first <= last ){  
      if ( arr[mid] < key ){  
        first = mid + 1;     
      }else if ( arr[mid] == key ){  
        System.out.println("Element is found at index: " + mid);  
        break;  
      }else{  
         last = mid - 1;  
      }  
      mid = (first + last)/2;  
   }  
   if ( first > last ){  
      System.out.println("Element is not found!");  
   }  
 }  
 public static void main(String args[]){  
        int arr[] = {10,20,30,40,50};  
        int key = 30;  
        int last=arr.length-1;  
        binarySearch(arr,0,last,key);     
 }  
}  
    
    
    
    
//// Binary Search in Java
//
//  int binarySearch(int array[], int element, int low, int high) {
//
//    // Repeat until the pointers low and high meet each other
//    while (low <= high) {
//
//      // get index of mid element
//      int mid = low + (high - low) / 2;
//
//      // if element to be searched is the mid element
//      if (array[mid] == element)
//        return mid;
//
//      // if element is less than mid element
//      // search only the left side of mid
//      if (array[mid] < element)
//        low = mid + 1;
//
//      // if element is greater than mid element
//      // search only the right side of mid
//      else
//        high = mid - 1;
//    }
//
//    return -1;
//  }
//
//  public static void main(String args[]) {
//
//    // create an object of Main class
//    Main obj = new Main();
//
//    // create a sorted array
//    int[] array = { 3, 4, 5, 6, 7, 8, 9 };
//    int n = array.length;
//
//    // get input from user for element to be searched
//    Scanner input = new Scanner(System.in);
//
//    System.out.println("Enter element to be searched:");
//
//    // element to be searched
//    int element = input.nextInt();
//    input.close();
//
//    // call the binary search method
//    // pass arguments: array, element, index of first and last element
//    
//     int result = obj.binarySearch(array, element, 0, n - 1);
//    if (result == -1)
//      System.out.println("Not found");
//    else
//      System.out.println("Element found at index " + result);
//  }
//}



//
//We can also use the recursive call to perform the same task.
//
//  int binarySearch(int array[], int element, int low, int high) {
//
//    if (high >= low) {
//      int mid = low + (high - low) / 2;
//
//      // check if mid element is searched element
//      if (array[mid] == element)
//        return mid;
//
//      // Search the left half of mid
//      if (array[mid] > element)
//        return binarySearch(array, element, low, mid - 1);
//
//      // Search the right half of mid
//      return binarySearch(array, element, mid + 1, high);
//    }
//
//    return -1;
//  }