/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructure;

import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;

/**
 *
 * @author Imran
 */
public class Bucket {
    public static void main(String[] args) {
        Float a[] = {0.56f, 0.78f, 0.72f, 0.87f, 0.15f, 0.1f, 0.11f};
        int size = a.length;

            Vector<Float> bucket[] = new Vector[10];
            for (int j = 0; j < 10; j++) {
                bucket[j] = new Vector<>();
            }

            for (int j = 0; j < size; j++) {
                float i = a[j] * 10;

                int index = (int) i;

                bucket[index].add(a[j]);
            }

            for (int j = 0; j < size; j++) {
                Collections.sort(bucket[j]);
            }

            int idx = 0;

            for (int j = 0; j < size; j++) {

                for (int i = 0; i < bucket[j].size(); i++) {

                    a[idx] = bucket[j].get(i);
                    idx = idx + 1;
                }
            }
            System.out.println("bucket"+Arrays.toString(bucket));
            System.out.println("Sorted Array: "+Arrays.toString(a));
    }
}
