//
package DataStructure;
import java.util.*;

public class Insertion_Sort 
{

    public void insertion_sort(int arr[]) 
    {
        int n = arr.length;
        System.out.println(Arrays.toString(arr));

        for (int i = 1; i <n; i++) 
        {
            System.out.println("Pass(" + (i) + "): ");
            for (int j = i; j>0 ; j--) 
            {
                if (arr[j-1] > arr[j]) 
                {
                    int temp = arr[j-1];
                    arr[j-1] = arr[j];
                    arr[j] = temp;
                    System.out.println("Swap [" + (j) + "] : " + Arrays.toString(arr));
                }
                    
            }
                
        }
            System.out.println("Sorted Data: " + Arrays.toString(arr));
    }
}

// Insertion sort in Java

//import java.util.Arrays;
//
//class InsertionSort {
//
//  void insertionSort(int array[]) {
//    int size = array.length;
//
//    for (int step = 1; step < size; step++) {
//      int key = array[step];
//      int j = step - 1;
//
//      // Compare key with each element on the left of it until an element smaller than
//      // it is found.
//      // For descending order, change key<array[j] to key>array[j].
//      while (j >= 0 && key < array[j]) {
//        array[j + 1] = array[j];
//        --j;
//      }
//
//      // Place key at after the element just smaller than it.
//      array[j + 1] = key;
//    }
//  }
//
//  // Driver code
//  public static void main(String args[]) {
//    int[] data = { 9, 5, 1, 4, 3 };
//    InsertionSort is = new InsertionSort();
//    is.insertionSort(data);
//    System.out.println("Sorted Array in Ascending Order: ");
//    System.out.println(Arrays.toString(data));
//  }
//}