package DataStructure;

import Graph.GraphRepresent;                                         // Copy: Ctl + Shift + Down Arrow
import static DataStructure.Fibonacci_Arithmatic_Operation.MAX;      // Comment: Ctl + Shift + C
//import static DataStructure.Linear_Search.linearSearch;

import Graph.BFS_Graph;                                              // Right Shift : Shift + Alt + Right Arrow
import Graph.DFS_Graph;                                              // Right Shift : Shift + Alt + Right Arrow
import java.util.Scanner;                                            // Formet : Shift + Alt + F

public class Algorithm {                                             //Delete Line: Shift +  

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("-------------------------------\n"
                    + "        *Computer Algorithms*           \n"
                    + "-------------------------------\n"
                    + "        1.Data Structure\n"
                    + "        2.Algorithm\n");

            System.out.println("Type your choice>:");
            int choice = s.nextInt();
            if (choice == 1) {
                System.out.println("----------------\n"
                        + "1.Linear  Search\n"
                        + "2.Binary Search\n"
                        + "3.Bubble Sort\n"
                        + "4.Insertion Sort\n"
                        + "5.Selection Sort\n"
                        + "6.Merge Sort\n"
                        + "7.Quick Sort\n"
                        + "8.Counting Sort\n"
                        + "9.Radix Sort\n"
                        + "10.Bucket Sort\n"
                        + "11.Shell Sort\n"
                        + "12.Stack\n"
                        + "13.Queue\n"
                        + "14.Link List\n"
                        + "15.Heap Sort\n"
                        + "16.Binary Search Tree\n"
                        + "17.Fibonacci Numbers\n"
                        + "18.Euclidean GCD Algorithm\n"
                        + "19.Universal Hashing\n"
                        + "20.Factorial Number\n");

               
                System.out.println("Enter Your Data Structure Choice >: ");
                int n1 = s.nextInt();

                switch (n1) {
                    case 1:
                        Linear_Search ls= new Linear_Search();
                        int[] a1= {10,20,30,50,70,90};    
        int key = 50;    
        System.out.println(key+" is found at index: "+ls.linearSearch(a1, key));
                        
                        break;
                    case 2:
                        break;
                    case 3:
                        Input in = new Input();

                        Bubble_Sort b = new Bubble_Sort();
                        b.bubble_sort(in.sort_input());
                        break;
                    case 4:
                        Insertion_Sort insert = new Insertion_Sort();
                        Input info = new Input();
                        insert.insertion_sort(info.sort_input());
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                    case 7:
                        break;
                    case 8:
                        break;
                    case 9:
                        break;
                    case 10:
                        break;
                    case 11:
                        break;
                    case 12:
                        break;
                    case 13:
                        break;
                    case 14:
                        Linked lk = new Linked();
                        lk.linked_display();
                        break;
                    case 15:
                        break;
                    case 16:
                        break;

                    case 17:
                        Fibonacci_Loop fl = new Fibonacci_Loop();
                        Fibonacci_Recursion fr = new Fibonacci_Recursion();
                        Fibonacci_Dynamic fd = new Fibonacci_Dynamic();
                        Fibonacci_Power_of_Matrix fp = new Fibonacci_Power_of_Matrix();
                        Fibonacci_Arithmatic_Operation fa = new Fibonacci_Arithmatic_Operation();
                        Fibonacci_Formulae ff = new Fibonacci_Formulae();

                        Scanner sc = new Scanner(System.in);
                        System.out.println("Enter the method to find fibonacci Series :\n"
                                + "1.Loop\n"
                                + "2.Recursive\n"
                                + "3.Fibonacci_Dynamic_Array\n"
                                + "4.Fibonacci_Power_of_Matrix\n"
                                + "5.Fibonacci_O(Log n)Arithmatic_Operation\n"
                                + "6.Fibonacci_Formulae");
                        int a = sc.nextInt();
                        switch (a) {
                            case 1:
                                System.out.println("Enter fibonacci series upto required: ");
                                int n11 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n11 + " is:");
                                for (int i = 0; i < n11; i++) {
                                    System.out.println(ff.fib(i));
                                }

                                break;
                            case 2:

                                System.out.println("Enter fibonacci series upto required: ");
                                int n2 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n2 + " is:");
                                for (int i = 0; i < n2; i++) {
                                    System.out.println(fr.fib(i));
                                }
                                break;
                            case 3:
                                System.out.println("Enter fibonacci series upto required: ");
                                int n3 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n3 + " is :");
                                for (int i = 0; i < n3; i++) {
                                    System.out.println(fd.fib(i));
                                }
                                break;
                            case 4:
                                System.out.println("Enter fibonacci series upto required: ");
                                int n4 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n4 + " is : ");
                                for (int i = 0; i < n4; i++) {
                                    System.out.println(fp.fib(i));
                                }
                                break;
                            case 5:
                                System.out.println("Enter fibonacci series upto required: ");
                                int n5 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n5 + " is :");
                                //nt[] f = new int[MAX];
                                //.fib(f);
                                for (int i = 0; i < n5; i++) {
                                    System.out.println(fa.fib(i));
                                }
                                break;
                            case 6:
                                System.out.println("Enter fibonacci series upto required: ");
                                int n6 = sc.nextInt();
                                System.out.println("Fibonacci series upto " + n6 + " is :");
                                for (int i = 0; i < n6; i++) {
                                    System.out.println(ff.fib(i));
                                }
                                break;
                            default:
                                throw new AssertionError();
                        }
                        break;
                    case 18:
                        break;
                    case 19:
                        break;

                    case 20:
                        Factorial_Recursion fa_r = new Factorial_Recursion();
                        Factorial_Loop fa_l = new Factorial_Loop();
                        Scanner sc1 = new Scanner(System.in);
                        System.out.println("Enter the method to find fibonacci Series :\n "
                                + "1.Recursion \n"
                                + " 2.Loop");
                        int c = sc1.nextInt();
                        if (c == 1) {
                            System.out.println("Enter required factorial number: ");
                            int n = sc1.nextInt();
                            System.out.println("The Factorial Value of " + n + " is\n" + fa_r.factorial(n));

                            break;
                        } else {
                            System.out.println("Enter required factorial number : ");
                            int n = sc1.nextInt();
                            fa_l.factorial(n);
                            break;

                        }

                    default:
                        break;
                }
            } else {
                System.out.println("----------------------------------\n"
                        + "           *Algorithm*              \n"
                        + " ---------------------------------\n"
                        + "               1.Graph Representation\n"
                        + "               2.BFS\n"
                        + "               3.DFS\n"
                        + "               4.Topological Sort\n"
                        + "               5.Krushkal\n"
                        + "               6.Prim's\n"
                        + "               7.Dijkastra\n"
                        + "               8.Bellman-Ford\n"
                        + "               9.Floyed-/Warshall\n"
                        + "               10.Longest Common Subsequence\n"
                        + "               11.Longest Increasing Sunsequence\n"
                        + "               12.Strassen's matrix multiplication\n"
                        + "               13.Knapsack Problem\n"
                        + "               14.Activity Selection Problem\n"
                        + "               15.Naive String Matching\n"
                        + "               16.Rabin Karp String Matching\n");

                   }
            
            System.out.println("Type your Algorithm Choice >: ");
            int n2 = s.nextInt();
            switch (n2) {
                case 1:
                    GraphRepresent gl = new GraphRepresent();
                    gl.graph_represent();
                    break;
                case 2:
                    BFS_Graph g2 = new BFS_Graph(4);
                    g2.addEdge(0, 1);
                    g2.addEdge(0, 2);
                    g2.addEdge(1, 2);
                    g2.addEdge(2, 0);
                    g2.addEdge(2, 3);
                    g2.addEdge(3, 3);

                    System.out.println("Following is Breadth First Traversal " + "(starting from vertex 2)");
                    g2.BFS(2);
                    //g2.BFS_Graph();
                    break;
                case 3:
                    DFS_Graph g3 = new DFS_Graph(4);

                    g3.addEdge(0, 1);
                    g3.addEdge(0, 2);
                    g3.addEdge(1, 2);
                    g3.addEdge(2, 3);

                    System.out.println("Following is Depth First Traversal");

                    g3.DFS(0);
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                    break;
                default:
                    break;

            }
        }
    }

}
